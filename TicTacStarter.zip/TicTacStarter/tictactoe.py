"""
Tic Tac Toe Player
"""

import math
import copy

X = "X"
O = "O"
EMPTY = None


def initial_state():
    """
    Returns starting state of the board.
    """
    return [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]


def player(board):
    """
    Returns player who has the next turn on a board.
    """
    xCount = 0
    oCount = 0
    for row in range(3):
        for column in range(3):
            if(board[row][column] == X):
                xCount = xCount+1
            elif(board[row][column] == O):
                oCount = oCount+1
    if(xCount > oCount):
        return O
    else:
        return X


def actions(board):
    """
    Returns set of all possible actions (i, j) available on the board.
    """
    actions = []
    for row in range(3):
        for column in range(3):
            if(board[row][column] == EMPTY):
                actions.append((row, column))
    return actions


def result(board, action):
    """
    Returns the board that results from making move (i, j) on the board.
    """
    if(action[0] >= 0 and action[0] <3) and (action[1] >= 0 and action[1] <3):
        mark = player(board)
        copyBoard = [row[:] for row in board]
        copyBoard[action[0]] [action[1]] = mark
        return copyBoard
    else:
        raise ValueError("invalid coordinates for action")


def winner(board):
    """
    Returns the winner of the game, if there is one.
    """
    if checkWin(board, X):
        #print("X won")
        return X
    elif checkWin(board, O):
        #print("O won")
        return O
    else:
        #print("nobody won")
        return None


def terminal(board):
    """
    Returns True if game is over, False otherwise.
    """
    if(board[0][0] == board[0][1] == board[0][2] and board[0][0] != EMPTY):#top row
        return True
    elif( board[1][0] == board[1][1] == board[1][2] and board[1][0] != EMPTY):#middle row
        return True
    elif (board[2][0] == board[2][1] == board[2][2]and board[2][0] != EMPTY):#bottom row
        return True
    elif(board[0][0] == board[1][0] == board[2][0]and board[0][0] != EMPTY):#left column
        return True
    elif (board[0][1] == board[1][1] == board[2][1]and board[0][1] != EMPTY):#middle column
        return True
    elif (board[0][2] == board[1][2] == board[2][2]and board[0][2] != EMPTY):##right column
        return True
    elif(board[0][0] == board[1][1] == board[2][2]and board[0][0] != EMPTY):#diagonal top left to bottom right
        return True
    elif(board[0][2] == board[1][1] == board[2][0]and board[0][2] != EMPTY):# diagonal top right to bottom left
        return True
    elif (board[0][0] != EMPTY and board[0][1] != EMPTY and board[0][2] != EMPTY and board[1][0] != EMPTY and board[1][1] != EMPTY and board[1][2] != EMPTY and board[2][0] != EMPTY and board[2][1] != EMPTY and board[2][2] != EMPTY):#cat's game
        return True
    else:
        return False


def checkWin(board, mark):
    """Checks if there is a win for the mark passed"""
    if(board[0][0] == mark and board[0][1] == mark and board[0][2] == mark):
        return True
    elif(board[1][0] == mark and board[1][1] == mark and board[1][2]== mark):
        return True
    elif(board[2][0] == mark and board[2][1] == mark and board[2][2]== mark):
        return True
    elif(board[0][0] == mark and board[1][0] == mark and board[2][0]== mark):
        return True
    elif (board[0][1] == mark and board[1][1] == mark and board[2][1]== mark):
        return True
    elif(board[0][2] == mark and board[1][2] == mark and board[2][2]== mark):
        return True
    elif(board[0][0] == mark and board[1][1] == mark and  board[2][2]== mark):
        return True
    elif(board[0][2] == mark and board[1][1] == mark and board[2][0] == mark):
        return True
    else:
        return False


def utility(board):
    """
    Returns 1 if X has won the game, -1 if O has won, 0 otherwise.
    """
    if checkWin(board, X):
        return 1
    elif checkWin(board, O):
        return -1
    else:
        return 0


 #NOT DONE
def minimax(board):
    """
    Returns the optimal action for the current player on the board.
    """
    bestMove = None
    if terminal(board):
        return None

    if(player(board)== X):
        bestMove,value = maxValue(board)
    else:
        bestMove,value = minValue(board)

    return bestMove#the last one in list


def maxValue(board):
    if(terminal(board)):
        return actions(board),utility(board)
    value = -math.inf
    for x in actions(board):
        action2,value2 = minValue(result(board,x))

        if value2 > value:
            value = value2
            move = x
    return move,value



def minValue(board):
    if(terminal(board)):
        return actions(board), utility(board)
    value = math.inf
    for x in actions(board):
        action2,value2 = maxValue(result(board,x))
        if value2 < value:
            value = value2
            move = x
    return move,value
