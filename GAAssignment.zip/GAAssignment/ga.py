from chromosome import *
import matplotlib.pyplot as plt
import random
import sys
import copy

def main():
    poolSize = 40
    mutationRate= 0.001
    crossoverRate = 0.7
    genCount = 0
    targetFound = False
    newPool = []
    pool = []
    if len(sys.argv) == 2:
        target = sys.argv[1]

    else:
        target = 42

    #creates initial pool of chromosomes
    while (len(pool) < poolSize):
        newChromo = Chromosome(target)
        if(newChromo.isValid()):
            pool.append(newChromo)
    #loops until target is found
    while(targetFound == False and len(pool) > 1):
        newPool.clear()
        genCount+=1

        pool.sort(key=lambda x: x.score,reverse=False)
        print(pool)
        #loops if pool list is large enough to pop 2
        while(len(pool) > 1):

            chromo1 = pool.pop(0)
            chromo2 = pool.pop(0)

            chromo1.crossover(chromo2, crossoverRate)

            chromo1.mutate(mutationRate)
            chromo2.mutate(mutationRate)

            chromo1.scoreChromo()
            chromo2.scoreChromo()
            #adds chromo to new pool only if it is valid
            if(chromo1.isValid()):
                newPool.append(chromo1)
            if(chromo2.isValid()):
                newPool.append(chromo2)
            if(chromo1.score == 0):
                print("I FOUND THE TARGET!")
                print(f"Target: {target} was found in generation {genCount}")
                targetFound = True
                return
            if(chromo2.score == 0):
                print("I FOUND THE TARGET!")
                print(f"Target: {target} was found in generation {genCount}")
                targetFound = True
                return

        #appending new pool to pool if anything is in list.
        for i in range(len(newPool)):
            pool.append(newPool[i])
        #assures pool is filled
        while (len(pool) < poolSize):
            newChromo = Chromosome(target)
            if(newChromo.isValid()):
                pool.append(newChromo)



main()
