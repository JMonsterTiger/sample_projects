from node import *
from nodeG import *
from nodeA import *
import sys
import heapq
import matplotlib.pyplot as plt

def main():
    if len(sys.argv) == 2:
        filename = sys.argv[1]
        with open(filename) as f:
            lines = [line.rstrip() for line in f]
            goal = lines[len(lines)-1].split(" ")

        for i in range(len(lines)-1):
            start = lines[i].split(" ")
            print(start)

            n = Node(start, None, "Start", True)
            nodeG1 = NodeG(start, None, "Start", True, "manhattan", goal)
            nodeG2 = NodeG(start, None, "Start", True, "misPlace", goal)

            nodeA1 = NodeA(start, None, "Start", True, "manhattan", goal)
            nodeA2 = NodeA(start, None, "Start", True, "misPlace", goal)

            print(i)
            if n.solvable(goal):
                explored = []
                print("BFS")
                explored.append(search(n, goal, 1))
                print("DFS")
                explored.append(search (n, goal, 2))
                print("UCS")
                explored.append(search (n, goal, 3))


                #add the call for greedy and A* search here
                print("Greedy Manhattan")
                explored.append(newSearch (nodeG1,goal,1))
                print("A* Manhattan")
                explored.append(newSearch (nodeA1,goal,2))
                print("Greedy Out of Place")
                explored.append(newSearch (nodeG2,goal,3))
                print("A* Out of Place")
                explored.append(newSearch (nodeA2,goal,4))
            else:
                print("Unsolvable")
            plotBar(explored)

        return

    else:
        print("Pass me an input file! First line is the start stae: a series of integers separtated by a space digits 0 -8. Second line is the goal state")
        return

def plotBar(explored):
    searches=["BFS", "DFS", "UCS", "Greedy Man", "A* Man", "Greedy OOP", "A* OOP"]
    x_pos = [i for i, _ in enumerate(searches)]
    plt.bar(x_pos, explored, color='blue')
    plt.xlabel("Search type")
    plt.ylabel("Number of explored nodes")
    plt.xticks(x_pos, searches)
    plt.show()
def newSearch(start,goal,searchType):
    explored = []
    fringe = []
    numberExplored = 0
    tempCost = 0
    fringe.append(start)
    #probably need a for loop or while it isn't goal
    while(len(fringe) > 0):
        heapq.heapify(fringe)
        newNode = heapq.heappop(fringe)
        numberExplored+=1
        if(newNode.isGoal(goal)):
            print("Omg we found it")
            rebuildSolution(newNode) #not done
            return numberExplored
        else:
            #probably would add the while loop before each search type so that it loops
            #or in this else because we call this multiple times above for the graph... ;(
            explored.append(newNode.state)
            kids, moves = newNode.findKids()
            if(searchType == 1): #greedy manhattan
                for i in range(len(kids)):
                    if (kids[i] not in explored and newNode.getDepth() <= 10):
                        kidNode = NodeG(kids[i], newNode, moves[i], False, "manhattan", goal)
                        fringe.append(kidNode)
                        explored.append(kids[i])

            if(searchType == 2): #A*manhattan
                for i in range(len(kids)):
                    if (kids[i] not in explored and newNode.getDepth() <= 10):
                        kidNode = NodeA(kids[i], newNode, moves[i], False, "manhattan", goal)
                        fringe.append(kidNode)
                        explored.append(kids[i])

            if(searchType == 3): # greedy misplaced tiles
                for i in range(len(kids)):
                    if (kids[i] not in explored and newNode.getDepth() <= 10):
                        kidNode = NodeG(kids[i], newNode, moves[i], False, "misPlace", goal)
                        fringe.append(kidNode)
                        explored.append(kids[i])

            if(searchType == 4): #A*misplaced
                for i in range(len(kids)):
                    if (kids[i] not in explored and newNode.getDepth() <= 10):
                        kidNode = NodeA(kids[i], newNode, moves[i], False, "misPlace", goal)

                        fringe.append(kidNode)
                        explored.append(kids[i])

    print("Unable to solve at current depth")
    return numberExplored


def search(start, goal, searchType):
    explored = []
    fringe = []
    numberExplored = 0
    fringe.append(start)
    explored.append(start.state)
    while len(fringe) > 0:
        if searchType == 1: #BFS
            node = fringe.pop(0)
        elif searchType == 2: #DFS
            node = fringe.pop()
        elif searchType == 3: #UCSheapq.heapify(fringe[0])
            heapq.heapify(fringe)
            node = heapq.heappop(fringe)

        numberExplored+=1
        if(node.isGoal(goal)):
            print("Omg we found it")
            rebuildSolution(node) #not done
            return numberExplored
        else:
            kids, moves = node.findKids()
            for i in range(len(kids)):
                if (kids[i] not in explored and node.getDepth() <= 10):
                    newNode = Node(kids[i], node, moves[i], False)
                    fringe.append(newNode)
                    explored.append(kids[i])
    print("Unable to solve at current depth")
    return numberExplored

def rebuildSolution(node):
    stack = []
    while(node != None):
        stack.append(node)
        node = node.getParent()
    solution = []
    while(len(stack) >0):
        s = stack.pop()
        solution.append(s.getAction())
    print(f"moves to solution: {solution}")

main()
