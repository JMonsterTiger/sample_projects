import math

class City:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __repr__(self):
        """Returns the coordinates as a string"""
        return f" ({self.x}, {self.y})"
    
    def getX(self):
        """X coordinate"""
        return self.x
        
    def getY(self):
        """Y coordinate"""
        return self.y
        
    def distanceTo(self, other):
        '''determines the distance between two points
        '''
        xDistance = abs(self.getX() - other.getX())
        #print(f"xDistance ={xDistance}")
        yDistance = abs(self.getY() - other.getY())
        #print(f"yDistance ={yDistance}")
        return math.sqrt(abs((xDistance* xDistance) - (yDistance* yDistance)))