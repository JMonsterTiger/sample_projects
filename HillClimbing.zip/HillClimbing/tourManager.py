from city import *
import matplotlib.pyplot as plt
import random
class TourManager:
    def __init__(self):
        """a list of coordinates and a distance"""
        self.destinations=[]#holds the coordinates in the order visited
        self.distance = 0 #the distance of the tour
        
    
    def getDistance(self):
        """Calculates the tour of the cities back to start"""
        if self.distance == 0:#only calculate this if it is zero
            tourDist = 0
            for i in range(len(self.destinations)):
                currentCity = self.destinations[i]
                destinationCity = self.destinations[0]
                if i+1 < len(self.destinations):
                    destinationCity = self.destinations[i+1]
                tourDist+= currentCity.distanceTo(destinationCity)
            self.distance = tourDist
        return self.distance
    
    def setTour(self, newTourList):
        """Reset the tour to a new list of coordinates"""
        self.destinations = newTourList
    
    def shuffleTour(self):
        """Shuffle the order"""
        random.shuffle(self.destinations)
    
    def addCity(self, city):
        """add coordiantes to list"""
        self.destinations.append(city)
    
    def getCity(self, index):
        """get coordinates from the list"""
        return self.destinations[index]
        
    def setCity(self, index, city):
        """Insert a city into the list.  By doing so - you will
        need to for the distance of the tour to be recalculated"""
        self.destinations[index] = city
        self.distance = 0
    
    def numberOfCities(self):
        """:returns how many cities are in the tour"""
        return len(self.destinations)
    
    def cloneTour(self):
        """Make a clone of the list"""
        clone = []
        clone.extend(self.destinations)
        return clone
    
    def getXCoors(self):
        """This makes a list of the X coordinates of the cities in the
        order listed.  Useful for graphing"""
        xCoords =[]
        for c in self.destinations:
            xCoords.append(c.getX())
        #complete the cycle back to start
        xCoords.append(self.destinations[0].getX())
        return xCoords
    
    def getYCoors(self):
        """This makes a list of the Y coordinates of the cities in the
        order listed.  Useful for graphing"""
        yCoords =[]
        for c in self.destinations:
            yCoords.append(c.getY())
        #complete the cycle back to start
        yCoords.append(self.destinations[0].getY())
        return yCoords    
    
    def plotTour(self):
        """Makes a line graph connecting the points"""
        xCoords = self.getXCoors()
        yCoords = self.getYCoors()
        plt.plot(xCoords, yCoords)
        plt.show()
    
    def __repr__(self):
        """returns a string of the coordinates separated by a pipe"""
        s=""
        for c in self.destinations:
            s+= f"{c} | "
        return s