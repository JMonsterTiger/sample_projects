from city import *
from tourManager import *
import matplotlib.pyplot as plt
import random
import math
import sys
import copy

def main():

    numCities= 0#how many cities will be in the tour
    tourMan = TourManager() #is the list of cities
    if len(sys.argv) == 2: #if there are 2 then - they passed a file name
        filename = sys.argv[1]
        for line in open(filename):# each line of the file is x, y
            nums = line.split(",")
            x= int(nums[0])
            y = int(nums[1])
            city = City(x,y)
            tourMan.addCity(city)
            numCities+=1#this will keep track of how many were in the file
    else:#create some random x and y coordinates for the cities
        numCities = 20 #this can be changed if you want more cities
        for i in range(numCities):
            #having the coordinates be between 0-200 can change these if you want
            randomX = random.randint(0, 200)
            randomY = random.randint(0, 200)
            city = City(randomX,randomY)
            tourMan.addCity(city)

    trackGens=[]#this is for graphing
    numGens = 0#for graphing
    trackBest=[] #this is only for graphing purposes later


    #calculate the distance
    distance = tourMan.getDistance()#for graphing
    trackBest.append(distance)#this is only for graphing purposes later
    trackGens.append(numGens)#this is only for graphing purposes later

    print(f"The inital distance of this tour = {distance}")
    print(f"The inital tour: {tourMan}")
    #tourMan.plotTour()#if want to see starting
    #I decided I wanted to see the starting and ending side by side so I collected the starting
    originalXs = tourMan.getXCoors()
    originalYs = tourMan.getYCoors()
    #this is the best so far
    bestTour = tourMan
    #start looking at options that look better than you
    trackNumber = []
    tourTrack = []
    for x in range(0,10000):


        while(True):#do this until you make a successor that is not better than you
            newTour = TourManager()
            newTour.setTour(tourMan.cloneTour())#independent copy
            #grab random positions in tour to switch - this is the sucessor function
            pos1 = random.randint(0, numCities-1)
            pos2 = random.randint(0, numCities-1)

            city1 = newTour.getCity(pos1)
            city2 = newTour.getCity(pos2)

            #swap them
            newTour.setCity(pos2, city1)
            newTour.setCity(pos1, city2)

            numGens+=1
            if(tourMan.getDistance()> newTour.getDistance()):
                bestTour = copy.deepcopy(newTour)
                tourMan = copy.deepcopy(newTour)
                trackBest.append(bestTour.getDistance())#for graphing
                trackGens.append(numGens)#for graphing

            else:#your child was not better than you
                trackBest.append(bestTour.getDistance())#for graphing
                trackGens.append(numGens)#for graphing

                break #gets out of the loop
        tourTrack.append(bestTour.getDistance())
        trackNumber.append(x)
        #to inform you of your search
    print(f"The number of generations looked at: {numGens}")
    print(f"The final solution distance: {bestTour.getDistance()}")
    print(f"The tour: {bestTour}")
    bestXs = bestTour.getXCoors()#for graphing
    bestYs = bestTour.getYCoors()#for graphing
    #make the graphs
    plotInitAndBest(originalXs, originalYs, bestXs, bestYs)

    plotDistanceChangesGenerations(trackNumber, tourTrack, "tracking best distance over generations")

def plotInitAndBest(oXs, oYs, bXs, bYs):
    '''This creates a plot of two routs side by side to compare
       oXs stands for the original x coordinates
       oYs stands for the original y coordinates
       bXs stands for the best at the end x coordinates
       bYs stands for the best at the end y coordinates
    '''
    plt.subplot(1,2,1).set_title("Initial Route")
    plt.plot(oXs, oYs, "ro-", label="original", linewidth=2)
    plt.subplot(1,2,2).set_title("Best Route Found")
    plt.plot(bXs, bYs, "go--", label="best", linewidth= 1)
    plt.show()



def plotDistanceChangesGenerations(dist, gen, title):
    '''
        This makes a plot to show distance changes while the
        temperature changes
    '''
    plt.title(title)
    plt.xlabel('generations')
    plt.ylabel('distance')
    plt.plot(dist, gen, "ro-")
    plt.show()

main()
